# SACV v1 scientific freeze

## Frozen scientific rule
`PROTOCOL.md` is the binding SACV v1 method definition. No metric, analog offset, 10% contamination limit, support floor, annual center/radius selector, reciprocal cross-year gate, tie break, or exact-parent fallback may be changed based on any SonotaCo truth result or future GMN/OrbitTrace result.

## Frozen SonotaCo pretruth
The complete 888-candidate SACV membership map was produced label-free before opening the exposed SonotaCo truth artifact. It is preserved as `SONOTACO_FROZEN_MEMBERSHIP_MAP.json`.

## One-shot exposed SonotaCo result
The frozen map passed the predeclared same-parent paired gates. This is exposed cross-survey evidence, not pristine independent validation. It does not authorize OrbitTrace target access by itself.

## Pending target-excluded GMN gate
`build_pretruth.py` is a transport-generalized implementation of exactly the same SACV rule. An exhaustive 888/888 SonotaCo equivalence test produced zero membership mismatches against the frozen pretruth. `evaluate_truth.py` reproduces the exact frozen SonotaCo paired aggregates under the same parent-Hungarian/same-candidate logic.

The GMN run must use the exact target-excluded 2022/2023 geometry and exact PR #1377 fair parent catalogue. Complete SACV memberships must freeze before shower truth opens. A scientific FAIL closes SACV v1; no post-result rescue is authorized.

## Final target boundary
OrbitTrace remains inaccessible to SACV until the target-excluded GMN gate is completed. A later final blind application, if authorized by the gates, must freeze all eligible top-100 extraction memberships before exact-ID reveal and inherits rank <=100, >=4 target IDs/year, >=8 total, and target F1 >0.5.
