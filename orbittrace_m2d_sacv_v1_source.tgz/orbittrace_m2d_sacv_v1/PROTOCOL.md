# M2D seasonal-analog cross-validated membership v1 (SACV v1)

## Role
Secondary event-membership/extraction layer only. The exact baseline internal-mass M2D candidate existence, parent membership, score, rank, and comparator capacity are immutable. SACV may only return a subset of a parent or the exact parent fallback; it cannot create/merge/rerank families or recruit outside the parent.

## Frozen physical geometry
Use the existing OrbitTrace physical embedding without change:
- solar-longitude chord / `2 sin(5 deg/2)`;
- Sun-centered ecliptic radiant unit-vector chord / `2 sin(4 deg/2)`;
- `log(v_g) / log(1.1)`.
The inherited maximum local radius is exactly `1.0`; inherited support floor is exactly `4`.

## Annual source-only hypothesis selection
For each parent and each year independently:
1. Every same-year parent member is an eligible center.
2. Construct the 25 Moorhead seasonal analog centers by adding `60,70,...,300 deg` to solar longitude while keeping Sun-centered radiant and geocentric speed fixed.
3. Candidate cutoffs are every distance from the center to a same-year parent member inside radius 1.0, plus radius 1.0. A cutoff must contain at least 4 same-year parent members.
4. At each cutoff, `N_obs` is the count of every label-free same-year survey event inside the observed-center ball. `N_bg` is the arithmetic mean count inside the 25 analog-center balls at the identical cutoff.
5. A cutoff is admissible iff `N_bg/N_obs <= 0.10` and `N_obs-N_bg > 0`. The 10% contamination convention and 25 analog construction are inherited directly from Moorhead's per-shower false-positive method, not tuned here.
6. For a center, retain the largest admissible cutoff (Moorhead-style maximum retrieval subject to contamination control).
7. Select one annual hypothesis by maximum estimated excess `N_obs-N_bg`; deterministic ties use higher same-parent support, then lower modeled contamination, then smaller radius, then lexical event ID.

No annual truth, opposite-year data, target identity, target coordinate, orbit label, or post-result parameter enters annual selection.

## Reciprocal independent-year validation and fallback
After the two annual hypotheses are frozen:
- both annual hypotheses must exist;
- each selected center must lie inside the other year's selected ball (center distance <= both selected radii);
- each selected ball must contain at least 4 parent members from the opposite year.

If all conditions hold, the reportable extraction is the union of parent members lying inside either selected ball. Otherwise the reportable extraction is the exact unchanged parent membership.

Thus an annual hypothesis may overfit its own year, but it cannot shrink the candidate unless the independently selected other year corroborates the same physical neighborhood. No p-value is claimed from the source-year optimization.

## Frozen development/transfer gates
Use the already-established same-parent paired utility logic from M2D fixed4-drift-halo v1, with the seed-specific regrowth gate omitted because SACV has no seed:
- at least 20 parent-recovered assignments per comparator route;
- reportable extraction nonempty fraction >= 0.75;
- mean extraction precision >= 0.80;
- mean extraction precision strictly greater than parent precision;
- mean extraction F1 >= 0.75 * parent mean F1;
- among nonempty extractions, precision-nonregression fraction >= 0.50;
- at least one parent-recovered assignment must be strictly refined (anti-vacuity).

Parent discovery/literature metrics and ranks must reproduce exactly; halo/extraction rematching cannot rescue the primary same-parent gate.

## Final blind target boundary
Only after target-excluded development and no-retuning cross-survey transfer pass may SACV be applied to the already-blind M2D ranking. Final success inherits the existing firewall: rank <=100, >=4 exact target IDs per year, >=8 total, and exact target F1 >0.5. All top-100 extraction memberships freeze before exact-ID reveal. No target-informed rescue.
